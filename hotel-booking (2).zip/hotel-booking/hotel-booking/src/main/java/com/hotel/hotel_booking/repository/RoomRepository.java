package com.hotel.hotel_booking.repository;

import com.hotel.hotel_booking.model.Room;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Repository
public class RoomRepository {
    private final Map<Long, Room> store = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    public RoomRepository() {
        save(new Room(null, 1L, "101", "SINGLE", 50.0, 1, true));
        save(new Room(null, 1L, "102", "DOUBLE", 90.0, 2, true));
        save(new Room(null, 2L, "201", "SUITE", 200.0, 2, true));
        save(new Room(null, 3L, "301", "SINGLE", 40.0, 1, true));
    }

    public List<Room> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Room> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public List<Room> findByHotelId(Long hotelId) {
        return store.values().stream()
                .filter(r -> r.getHotelId().equals(hotelId))
                .collect(Collectors.toList());
    }

    public Room save(Room room) {
        if (room.getId() == null) {
            room.setId(idGen.getAndIncrement());
        }
        store.put(room.getId(), room);
        return room;
    }

    public boolean existsById(Long id) {
        return store.containsKey(id);
    }
}