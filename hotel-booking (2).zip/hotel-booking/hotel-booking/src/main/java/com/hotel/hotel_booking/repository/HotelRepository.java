package com.hotel.hotel_booking.repository;

import com.hotel.hotel_booking.model.Hotel;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class HotelRepository {
    private final Map<Long, Hotel> store = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    public HotelRepository() {
        save(new Hotel(null, "Grand Hotel", "Kyiv, Khreshchatyk 1", 5, "Luxury hotel in city center"));
        save(new Hotel(null, "Lviv Palace", "Lviv, Rynok Square 5", 4, "Historic hotel in old town"));
        save(new Hotel(null, "Odesa Pearl", "Odesa, Derybasivska 10", 3, "Cozy hotel near the sea"));
    }

    public List<Hotel> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Hotel> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Hotel save(Hotel hotel) {
        if (hotel.getId() == null) {
            hotel.setId(idGen.getAndIncrement());
        }
        store.put(hotel.getId(), hotel);
        return hotel;
    }

    public boolean existsById(Long id) {
        return store.containsKey(id);
    }
}