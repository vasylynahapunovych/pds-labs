package com.hotel.hotel_booking.repository;

import com.hotel.hotel_booking.model.Client;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class ClientRepository {
    private final Map<Long, Client> store = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    public ClientRepository() {
        save(new Client(null, "Ivan Petrenko", "ivan@gmail.com", "+380501234567"));
        save(new Client(null, "Olena Kovalenko", "olena@gmail.com", "+380679876543"));
    }

    public List<Client> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Client> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Client save(Client client) {
        if (client.getId() == null) {
            client.setId(idGen.getAndIncrement());
        }
        store.put(client.getId(), client);
        return client;
    }

    public boolean existsById(Long id) {
        return store.containsKey(id);
    }
}