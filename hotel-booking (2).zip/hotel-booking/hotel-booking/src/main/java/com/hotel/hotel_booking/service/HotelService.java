package com.hotel.hotel_booking.service;

import com.hotel.hotel_booking.exception.ResourceNotFoundException;
import com.hotel.hotel_booking.model.Hotel;
import com.hotel.hotel_booking.repository.HotelRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelService {

    private final HotelRepository hotelRepository;

    public HotelService(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }

    public Hotel getHotelById(Long id) {
        return hotelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel", id));
    }

    public Hotel createHotel(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    public Hotel updateHotel(Long id, Hotel updated) {
        Hotel existing = getHotelById(id);
        existing.setName(updated.getName());
        existing.setAddress(updated.getAddress());
        existing.setStars(updated.getStars());
        existing.setDescription(updated.getDescription());
        return hotelRepository.save(existing);
    }
}