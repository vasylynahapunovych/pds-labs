package com.hotel.hotel_booking.service;

import com.hotel.hotel_booking.exception.BusinessException;
import com.hotel.hotel_booking.exception.ResourceNotFoundException;
import com.hotel.hotel_booking.model.Booking;
import com.hotel.hotel_booking.model.BookingStatus;
import com.hotel.hotel_booking.model.Room;
import com.hotel.hotel_booking.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final RoomService roomService;
    private final ClientService clientService;

    public BookingService(BookingRepository bookingRepository, RoomService roomService, ClientService clientService) {
        this.bookingRepository = bookingRepository;
        this.roomService = roomService;
        this.clientService = clientService;
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", id));
    }

    public List<Booking> getBookingsByClient(Long clientId) {
        clientService.getClientById(clientId);
        return bookingRepository.findByClientId(clientId);
    }

    public Booking createBooking(Booking booking) {
        clientService.getClientById(booking.getClientId());
        Room room = roomService.getRoomById(booking.getRoomId());

        if (!booking.getCheckOut().isAfter(booking.getCheckIn())) {
            throw new BusinessException("Check-out date must be after check-in date");
        }

        checkRoomAvailability(booking.getRoomId(), booking.getCheckIn(), booking.getCheckOut(), null);

        long nights = ChronoUnit.DAYS.between(booking.getCheckIn(), booking.getCheckOut());
        booking.setTotalPrice(nights * room.getPricePerNight());
        booking.setStatus(BookingStatus.CREATED);

        return bookingRepository.save(booking);
    }

    public Booking confirmBooking(Long id) {
        Booking booking = getBookingById(id);
        if (booking.getStatus() != BookingStatus.CREATED) {
            throw new BusinessException("Only CREATED bookings can be confirmed");
        }
        booking.setStatus(BookingStatus.CONFIRMED);
        return bookingRepository.save(booking);
    }

    public Booking cancelBooking(Long id) {
        Booking booking = getBookingById(id);
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new BusinessException("Booking is already cancelled");
        }
        booking.setStatus(BookingStatus.CANCELLED);
        return bookingRepository.save(booking);
    }

    private void checkRoomAvailability(Long roomId, LocalDate checkIn, LocalDate checkOut, Long excludeBookingId) {
        List<Booking> existing = bookingRepository.findByRoomId(roomId);
        for (Booking b : existing) {
            if (b.getStatus() == BookingStatus.CANCELLED) continue;
            if (excludeBookingId != null && b.getId().equals(excludeBookingId)) continue;
            if (checkIn.isBefore(b.getCheckOut()) && checkOut.isAfter(b.getCheckIn())) {
                throw new BusinessException("Room is not available for selected dates");
            }
        }
    }
}