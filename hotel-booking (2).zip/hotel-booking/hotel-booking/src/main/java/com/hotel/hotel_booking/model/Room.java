package com.hotel.hotel_booking.model;

public class Room {
    private Long id;
    private Long hotelId;
    private String number;
    private String type;
    private double pricePerNight;
    private int capacity;
    private boolean available;

    public Room() {}

    public Room(Long id, Long hotelId, String number, String type, double pricePerNight, int capacity, boolean available) {
        this.id = id;
        this.hotelId = hotelId;
        this.number = number;
        this.type = type;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.available = available;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getHotelId() { return hotelId; }
    public void setHotelId(Long hotelId) { this.hotelId = hotelId; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public double getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(double pricePerNight) { this.pricePerNight = pricePerNight; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}