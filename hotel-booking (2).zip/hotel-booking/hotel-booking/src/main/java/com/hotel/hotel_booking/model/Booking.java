package com.hotel.hotel_booking.model;

import java.time.LocalDate;

public class Booking {
    private Long id;
    private Long roomId;
    private Long clientId;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private double totalPrice;
    private BookingStatus status;

    public Booking() {}

    public Booking(Long id, Long roomId, Long clientId, LocalDate checkIn, LocalDate checkOut, double totalPrice, BookingStatus status) {
        this.id = id;
        this.roomId = roomId;
        this.clientId = clientId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getRoomId() { return roomId; }
    public void setRoomId(Long roomId) { this.roomId = roomId; }
    public Long getClientId() { return clientId; }
    public void setClientId(Long clientId) { this.clientId = clientId; }
    public LocalDate getCheckIn() { return checkIn; }
    public void setCheckIn(LocalDate checkIn) { this.checkIn = checkIn; }
    public LocalDate getCheckOut() { return checkOut; }
    public void setCheckOut(LocalDate checkOut) { this.checkOut = checkOut; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }
}