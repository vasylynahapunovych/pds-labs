package com.hotel.hotel_booking.service;

import com.hotel.hotel_booking.exception.BusinessException;
import com.hotel.hotel_booking.exception.ResourceNotFoundException;
import com.hotel.hotel_booking.model.Booking;
import com.hotel.hotel_booking.model.BookingStatus;
import com.hotel.hotel_booking.model.Payment;
import com.hotel.hotel_booking.repository.PaymentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingService bookingService;

    public PaymentService(PaymentRepository paymentRepository, BookingService bookingService) {
        this.paymentRepository = paymentRepository;
        this.bookingService = bookingService;
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", id));
    }

    public Payment getPaymentByBooking(Long bookingId) {
        return paymentRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment for booking", bookingId));
    }

    public Payment confirmPayment(Payment payment) {
        Booking booking = bookingService.getBookingById(payment.getBookingId());

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new BusinessException("Cannot pay for a cancelled booking");
        }

        if (paymentRepository.findByBookingId(payment.getBookingId()).isPresent()) {
            throw new BusinessException("Payment for this booking already exists");
        }

        payment.setAmount(booking.getTotalPrice());
        payment.setStatus("PAID");
        payment.setDate(LocalDate.now());

        bookingService.confirmBooking(booking.getId());

        return paymentRepository.save(payment);
    }
}