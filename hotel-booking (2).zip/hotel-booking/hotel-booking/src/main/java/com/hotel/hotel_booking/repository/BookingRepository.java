package com.hotel.hotel_booking.repository;

import com.hotel.hotel_booking.model.Booking;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Repository
public class BookingRepository {
    private final Map<Long, Booking> store = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    public List<Booking> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Booking> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public List<Booking> findByClientId(Long clientId) {
        return store.values().stream()
                .filter(b -> b.getClientId().equals(clientId))
                .collect(Collectors.toList());
    }

    public List<Booking> findByRoomId(Long roomId) {
        return store.values().stream()
                .filter(b -> b.getRoomId().equals(roomId))
                .collect(Collectors.toList());
    }

    public Booking save(Booking booking) {
        if (booking.getId() == null) {
            booking.setId(idGen.getAndIncrement());
        }
        store.put(booking.getId(), booking);
        return booking;
    }

    public boolean existsById(Long id) {
        return store.containsKey(id);
    }
}