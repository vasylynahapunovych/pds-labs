package com.hotel.hotel_booking.model;

import java.time.LocalDate;

public class Payment {
    private Long id;
    private Long bookingId;
    private double amount;
    private String method;
    private String status;
    private LocalDate date;

    public Payment() {}

    public Payment(Long id, Long bookingId, double amount, String method, String status, LocalDate date) {
        this.id = id;
        this.bookingId = bookingId;
        this.amount = amount;
        this.method = method;
        this.status = status;
        this.date = date;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getBookingId() { return bookingId; }
    public void setBookingId(Long bookingId) { this.bookingId = bookingId; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}