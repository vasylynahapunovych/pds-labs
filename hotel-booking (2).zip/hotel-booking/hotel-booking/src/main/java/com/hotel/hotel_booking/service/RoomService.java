package com.hotel.hotel_booking.service;

import com.hotel.hotel_booking.exception.ResourceNotFoundException;
import com.hotel.hotel_booking.model.Room;
import com.hotel.hotel_booking.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomService {

    private final RoomRepository roomRepository;
    private final HotelService hotelService;

    public RoomService(RoomRepository roomRepository, HotelService hotelService) {
        this.roomRepository = roomRepository;
        this.hotelService = hotelService;
    }

    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room", id));
    }

    public List<Room> getRoomsByHotel(Long hotelId) {
        hotelService.getHotelById(hotelId);
        return roomRepository.findByHotelId(hotelId);
    }

    public Room createRoom(Room room) {
        hotelService.getHotelById(room.getHotelId());
        return roomRepository.save(room);
    }

    public Room updateRoom(Long id, Room updated) {
        Room existing = getRoomById(id);
        existing.setNumber(updated.getNumber());
        existing.setType(updated.getType());
        existing.setPricePerNight(updated.getPricePerNight());
        existing.setCapacity(updated.getCapacity());
        existing.setAvailable(updated.isAvailable());
        return roomRepository.save(existing);
    }
}