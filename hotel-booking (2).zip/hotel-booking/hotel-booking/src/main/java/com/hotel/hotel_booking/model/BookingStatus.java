package com.hotel.hotel_booking.model;

public enum BookingStatus {
    CREATED, CONFIRMED, CANCELLED
}