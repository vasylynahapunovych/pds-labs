package com.hotel.hotel_booking.repository;

import com.hotel.hotel_booking.model.Payment;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class PaymentRepository {
    private final Map<Long, Payment> store = new HashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    public List<Payment> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Payment> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Optional<Payment> findByBookingId(Long bookingId) {
        return store.values().stream()
                .filter(p -> p.getBookingId().equals(bookingId))
                .findFirst();
    }

    public Payment save(Payment payment) {
        if (payment.getId() == null) {
            payment.setId(idGen.getAndIncrement());
        }
        store.put(payment.getId(), payment);
        return payment;
    }
}